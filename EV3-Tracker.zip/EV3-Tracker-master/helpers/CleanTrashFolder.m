if isfolder('Trash')
      rmdir('Trash', 's');
      mkdir('Trash');
end