%Clear workspace
clear
clc